<?php
require('db.php');

	$p_id=$_POST['id'];


  $deleteProduct= $conn->query("Delete from product WHERE p_id='".$p_id."'");
	$deleteStock= $conn->query("DELETE  from stock WHERE p_id='".$p_id."'");
	$deletehistory= $conn->query("DELETE  from product_operation_history WHERE pid='".$p_id."'");
  if($deleteProduct)
  {
    ?>
          <script>
              alert('Product successfully deleted...');
              window.location.href='home_store.php';
          </script>
      <?php
  }
  else {
    ?>
          <script>
              alert('Error Acures');
              window.location.href='home_store.php';
          </script>
      <?php
  }
 ?>
