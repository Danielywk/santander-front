</div>
<!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
</div>
<!-- /. WRAPPER  -->

<div id="footer-sec" style="margin-left:250px;">
M/S. jahid Printers | Developed By : <a href="https://web.facebook.com/anupamhayatbd" target="_blank">Md. Anupam Hayat</a>,
<a href="https://www.facebook.com/riyajulislam.abir" target="_blank">Md.Riyajul Islam (Abir)</a>
</div>




</body>
</html>
