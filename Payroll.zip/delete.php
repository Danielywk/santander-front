<?php
	require('db.php');

	$id=$_GET['id'];
	$deleteEmployee = $conn->query("DELETE FROM employee WHERE emp_id=$id");
	
	

	$deleteSalary = $conn->query("DELETE FROM salary WHERE emp_id=$id");
	$deleteDeduction = $conn->query("DELETE FROM deductions WHERE emp_id=$id");

  if($deleteEmployee && $deleteSalary && $deleteDeduction)
  {
    ?>
          <script>
          
              window.location.href='home_employee.php';
          </script>
      <?php
  }
  else {
    ?>
          <script>
              alert('Error Acures');
              window.location.href='home_employee.php';
          </script>
      <?php
  }
 ?>
