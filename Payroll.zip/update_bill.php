<?php

		require("db.php");
		
if(isset($_POST['submitBillUpdate'])!="")
{
		$pay_status = '0';
    @$s_id			= $_POST['s_id'];
    @$billsno			= $_POST['billsno'];
		@$bill_amount			= $_POST['bill_amount'];
		@$received_date			= date('Y-m-d', strtotime($_POST['received_date']));
		@$received_amount		= $_POST['received_amount'];
		@$reduced		= $_POST['due'];

		if(($bill_amount-$received_amount) != 0){
			$pay_status = '2';
		}
		else if(($bill_amount-$received_amount) == 0){
			$pay_status = '1';
		}
		else{
			$pay_status = '0';
		}


    $sql = $conn->query("UPDATE companybill SET bill_amount='$bill_amount', receive_date='$received_date', receive_amount='$received_amount', pay_status='$pay_status', reduced='$reduced' where s_id = '".$s_id."'");

		if($sql)
		{
			?>
		        <script>
		            window.location.href="view_bill.php?bill_no=<?php echo $s_id ?>";
		        </script>
		    <?php
		}
		else {
      ?>
		        <script>
		            alert('Error Acures');
					window.location.href="view_bill.php?bill_no=<?php echo $s_id ?>";
		        </script>
		    <?php
		}
		
	}
 ?>
 
 <?php

if(isset($_POST['set'])!="")
{
    $s_id     = $_POST['s_id'];
   
    $sqlUpdate = $conn->query("UPDATE companybill SET pay_status='1'  where s_id = '".$s_id."'");

    if($sqlUpdate)
    {
        ?>
        <script>
            window.location.href="view_bill.php?bill_no=<?php echo $s_id ?>";
        </script>
        <?php
    }

    else
    {
        ?>
        <script>
            alert('Invalid.');
            window.location.href="view_bill.php?bill_no=<?php echo $s_id ?>";
        </script>
        <?php
    }
}
?>
